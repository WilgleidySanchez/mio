/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI.Diccionario;

/**
 *
 * @author Wilgleidys Sánchez
 * Fecha:02/06/2021*/

 /** Importamos el paquete api de google*/

import com.google.api.translate.Language;
import com.google.api.translate.Translate;

/*Librerias AWT*/
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/*Librerias SWING*/
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Traductor {
    /*definición de los componentes que conforman la GUI*/
    private JFrame frmTraductor;
    private JLabel lblPalabra,lblTraduccion,lblDicIng,lblDicFran,lblAddEsp,lblAddIng,lblAddFran;
    private JTextField txtPalabra,txtTraduccion,txtDicIng,txtDicFran,txtAddEsp,txtAddIng,txtAddFran;
    private BorderLayout brdEsquema;
    private JPanel pnlTraductor, pnlBoton,pnlDic,pnlAdd;
    private JButton btnIngles, btnFrances, btnAdicionar,btnSalir;
    private Container cntContenedor;
        
    public Traductor(){
    /* Invocamos el método que instancia los componentes de la GUI y otro método para ordenarlos y mostrarlos en pantalla*/
    inicializarComponentes();
    insertarComponentes();
    }//fin del método constructor
    
    private void inicializarComponentes(){
/*Este método se encarga de crear cada componente de la GUI dentro de este método se instanciará cada componente SWING y se agregaran a los esquemas de diseño*/

frmTraductor=new JFrame("Traductor" );
cntContenedor= new Container();
brdEsquema= new BorderLayout();
pnlTraductor= new JPanel();
pnlBoton= new JPanel();
pnlDic= new JPanel();
pnlAdd= new JPanel();
lblPalabra= new JLabel ("Palabra:");
lblTraduccion= new JLabel ("Traducción:");
lblDicIng= new JLabel("Ingles");
lblDicFran=new JLabel("Frances");
lblAddEsp= new JLabel("En Español");
lblAddIng=new JLabel("En Ingles");
lblAddFran=new JLabel("En Frances");

txtPalabra= new JTextField("",10);
txtTraduccion= new JTextField("",10);
txtDicIng= new JTextField("",10);
txtDicFran= new JTextField("",10);
txtAddEsp= new JTextField("",10);
txtAddIng= new JTextField("",10);
txtAddFran= new JTextField("",10);

btnIngles= new JButton("En Inglés");
btnFrances= new JButton("En Francés");    
btnAdicionar= new JButton("Adicionar");
btnSalir= new JButton("Salir");

  }// fin de método inicializarComponentes()
    
    private void agruparLblTxt(JPanel panel1,JPanel panel2,JPanel panel3,JLabel etiquetaA,JTextField cajaTexto,JLabel etiquetaB,
        JTextField cajaTextoB,JLabel etiquetaC,JTextField cajaTextoC,JLabel etiquetaD,
        JTextField cajaTextoD,JLabel etiquetaE,JTextField cajaTextoE,JLabel etiquetaF,
        JTextField cajaTextoF,JLabel etiquetaG,
        JTextField cajaTextoG){
/*Este método recibe como parametros 3 paneles, 7 etiquetas, 7 cuadros de texto simple 
        luego signa al panel un esquema de tipo GridLayout de 7 filas,2 columnas.
    Por ultimo, agrega los componentes en orden*/

panel1.setLayout(new GridLayout(7,2));
panel1.add(etiquetaA);
panel1.add(cajaTexto);
panel1.add(etiquetaB);
panel1.add(cajaTextoB);
panel2.add(etiquetaC);
panel2.add(cajaTextoC);
panel2.add(etiquetaD);
panel2.add(cajaTextoD);
panel3.add(etiquetaE);
panel3.add(cajaTextoE);
panel3.add(etiquetaF);
panel3.add(cajaTextoF);
panel3.add(etiquetaG);
panel3.add(cajaTextoG);
    
}//fin de método agruparLblTxt()

private void agruparBotones(JPanel panel,JPanel panel3, JButton botonA, JButton botonB,
        JButton botonC,JButton botonD){
/*Este método recibe como parametros 2 paneles, 4 botones luego signa al panel un esquema
    de tipo BorderLayout. por último, agrega un botón del lado OESTE y otro del lado ESTE del panel,
    otro al SUR y el ultimo al NORTE*/
panel.setLayout(new BorderLayout());
panel.add(botonA, BorderLayout.WEST);
panel.add(botonB, BorderLayout.EAST);
panel3.add(botonC, BorderLayout.SOUTH);
panel3.add(botonD, BorderLayout.NORTH);
 
}//Fin de método agruparBotones()

    private void insertarComponentes() {
      /*Este método se encarga de insertar los componentes en los paneles y visualizar la GUI*/
      
      /*Obtenemos el panel del JFrame*/
      cntContenedor= frmTraductor.getContentPane();
      /*Asignamos el esquema de tipo BoderLayout*/
      cntContenedor.setLayout(brdEsquema);
      
      /*Invocamos los métodos para agrupar las etiquetas, cuadros de textos y botones*/
      
      agruparLblTxt(pnlTraductor,pnlDic,pnlAdd, lblPalabra,txtPalabra, lblTraduccion,txtTraduccion,
      lblDicIng,txtDicIng,lblDicFran,txtDicFran,lblAddEsp,txtAddEsp,lblAddIng,txtAddIng,lblAddFran,txtAddFran );
      agruparBotones(pnlBoton,pnlAdd, btnIngles, btnFrances,btnAdicionar,btnSalir);
      /*Agregamos los paneles con los componentes agrupados en el lado NORTE , SUR, ESTE y OESTE del contenedor principal*/
      cntContenedor.add(pnlTraductor, BorderLayout.NORTH);
      cntContenedor.add(pnlBoton, BorderLayout.SOUTH);
      cntContenedor.add(pnlDic, BorderLayout.EAST);
      cntContenedor.add(pnlAdd, BorderLayout.WEST);
      /*Compactamos el JFrame al tamaño del componente*/
      
      frmTraductor.pack();
      
      /*Posicionamos el JFrame en el centro de la pantalla*/
      frmTraductor.setLocationRelativeTo(null);
      
      /*Con esta instrucción el JFrame se cerrará al pulsar en el botón (x)*/
      
      frmTraductor.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
      /*Hacemos que nuestro JFrame pueda verse en pantalla*/
      
      frmTraductor.setVisible(true);
      
      
    }//fin del método insertarComponentes()
    /** configuramos el boton para que traduzca las palabras de español al ingles*/
    private void btnInglesActionPerformed (java.awt.event.ActionEvent evt) {                                              
        try{
String original =(String) this.txtPalabra.getText();
String translatedText = Translate.translate(original, Language.SPANISH, Language.ENGLISH);
this.txtTraduccion.setText(translatedText);
}catch(Exception ex)
{
System.out.println("Error " + ex);

    }                                             
}
        /** configuramos el boton para que traduzca las palabras de español al frances*/
private void btnFrancesActionPerformed(java.awt.event.ActionEvent evt) {                                               
try{
this.lblPalabra.setVisible(true);
String original =(String) this.txtPalabra.getText();
String translatedText = Translate.translate(original, Language.SPANISH, Language.FRENCH );
this.txtTraduccion.setText(translatedText);
this.lblPalabra.setVisible(false);
}catch(Exception ex)
{
System.out.println("Error " + ex);
}
    }  
         
    
}