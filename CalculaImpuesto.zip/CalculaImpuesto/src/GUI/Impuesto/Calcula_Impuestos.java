/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI.Impuesto;

import java.util.ArrayList;
import java.io.*;

/*Librerias AWT*/
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/*Librerias SWING*/
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Wilgleidys Sánchez
 * Fecha:01/06/2021
 */
public class Calcula_Impuestos { 
    
     /*definición de los componentes que conforman la GUI*/
    private JFrame frmImpuestos;
    private JLabel lblMarca,lblLinea,lblModelo,lblValor,lblMontodescuento,lblTotalapagar;
    private JTextField txtMarca,txtLinea,txtModelo,txtValor,txtMontodescuento,txtTotalapagar;
    private BorderLayout brdEsquema;
    private JPanel pnlImpuestos, pnlBoton;
    private JButton btnBuscar, btnDescuento,btnCalcular,btnLimpiar;
    private Container cntContenedor;
    
     // Constantes

    //** Porcentaje de descuento por pronto pago */
    public static final double PORC_DSC_PRONTO_PAGO = 10.0;
    //** Descuento por servicio publico */
    public static final double DESC_SERVICIO_PUBLICO = 40000.0;
    
    // Atributos

    /** Marcas de vehículos*/
    private ArrayList marca;
      /** Rango de impuestos */
    private ArrayList RangoImpuestos;

       /* Invocamos el método que instancia los componentes de la GUI y otro método para ordenarlos y mostrarlos en pantalla*/
    
   public Calcula_Impuestos()throws Exception{
   inicializarComponentes();
   insertarComponentes();
    marca = new ArrayList( );
    RangoImpuestos = new ArrayList( );
    cargarVehiculos( "vehiculos.txt" );
    cargarTablaImpuestos( "impuestos.properties" );
    } //fin del método constructor
   
    private void inicializarComponentes(){
/*Este método se encarga de crear cada componente de la GUI dentro de este método se instanciará cada componente SWING y se agregaran a los esquemas de diseño*/

frmImpuestos=new JFrame("Impuestos" );
Manejador manejaEvento= new Manejador();
cntContenedor= new Container();
brdEsquema= new BorderLayout();
pnlImpuestos= new JPanel();
pnlBoton= new JPanel();
lblMarca= new JLabel ("Marca:");
lblLinea= new JLabel ("Linea");
lblModelo= new JLabel ("Modelo");
lblValor= new JLabel ("Valor");
lblMontodescuento= new JLabel ("Monto de descuento");
lblTotalapagar= new JLabel ("Total a Pagar");

txtMarca= new JTextField("",10);
txtLinea= new JTextField("",10);
txtModelo= new JTextField("",10);
txtValor= new JTextField("",10);
txtMontodescuento= new JTextField("",10);
txtTotalapagar= new JTextField("",10);
btnBuscar= new JButton("Buscar");
btnDescuento= new JButton("Descuento");
btnCalcular= new JButton("Calcular");
btnLimpiar= new JButton("Limpiar");

btnBuscar.addActionListener(manejaEvento);
btnDescuento.addActionListener(manejaEvento);
btnCalcular.addActionListener(manejaEvento);
btnLimpiar.addActionListener(manejaEvento);

    }// fin de método inicializarComponentes()

 
    private Marca buscarMarca( String nombre )
    {
        Marca marca = null;
        for( int i = 0; i < marca.size( ) && marca == null; i++ )
        {
            Marca marcaAux = ( Marca )marca.get(i );
            if( marcaAux.toString().equalsIgnoreCase( nombre ) )
                marca = marcaAux;
        }
        return marca;
    }

    

     private void cargarVehiculos( String archivo ) throws Exception
    {
        Marca marcas;
        Linea linea;
        Modelo modelo;
        String texto, valores[], sMarca, sLinea, sModelo;
        double precio;
        BufferedReader lector;
        try
        {
            File datos = new File( archivo );
            lector = new BufferedReader( new FileReader( datos ) );
            texto = lector.readLine( );
        }
        catch( Exception e )
        {
            throw new Exception( "Error al cargar los datos almacenados de vehículos" );
        }

        while( texto != null )
        {
            //Si comienza con # es comentario
            if( !texto.startsWith( "#" ) && !texto.equals( "" ) )
            {
                //Lee los datos
                valores = texto.split( "," );

                if( valores.length < 3 )
                    throw new Exception( "Faltan datos línea: " + texto );

                sMarca = valores[ 0 ];
                sLinea = valores[ 1 ];
                sModelo = valores[ 2 ];
                try
                {
                    precio = Double.parseDouble( valores[ 3 ] );
                }
                catch( Exception e )
                {
                    throw new Exception( "El valor de precio debe ser numérico: " + valores[ 3 ] );
                }
                //Crea la configuración de un vehículo según los datos
                //Busca la marca del vehiculo
                marcas = buscarMarca( sMarca );
                
                //A la marca le busca o le adiciona una línea
                linea = marcas.buscarLinea ( sLinea );
                if( linea == null )
                {
                    linea = new Linea( sLinea );
                    marcas.adicionarLinea( linea );
                }
                //A la línea le busca o adiciona un modelo
                modelo = linea.buscarModelo ( sModelo );
                if( modelo == null )
                {
                    modelo = new Modelo( sModelo, precio );
                    linea.adicionarModelo( modelo );
                }
            }
            try
            {
                //siguiente línea
                texto = lector.readLine( );
            }
            catch( Exception e )
            {
                throw new Exception( "Error al cargar los datos almacenados de vehículos" );
            }
        }
    }

    /**
     * Carga la tabla de impuestos por los rangos. <br>
     * <b>post: </b> Se cargan todos valores de impuestos según los rangos de valores.
     * @param archivo Ubicación del archivo a leer. archivo != null.
     * @throws Exception Si ocurre un error al cargar los rangos.
     */
    private void cargarTablaImpuestos( String archivo ) throws Exception
    {
        Properties datos = new Properties( );
        int rangos = 0;
        String texto, valores[];
        double inicio, fin, porcentaje;
        RangoImpuestos rango;
        try
        {
            FileInputStream input = new FileInputStream( archivo );
            datos.load( input );
        }
        catch( Exception e )
        {
            throw new Exception( "Error al cargar los rangos de impuestos" );
        }

        try
        {
            rangos = Integer.parseInt( datos.getProperty( "numero.rangos" ) );
        }
        catch( Exception e )
        {
            throw new Exception( "El número de rangos de impuestos es inválido" );
        }

        //Carga todos los rangos
        for( int i = 1; i <= rangos; i++ )
        {
            texto = datos.getProperty( "rango" + i );
            if( texto == null )
                throw new Exception( "Falta la definición de rango" + i );
            valores = texto.split( "," );
            try
            {
                inicio = Double.parseDouble( valores[ 0 ] );
                fin = Double.parseDouble( valores[ 1 ] );
                porcentaje = Double.parseDouble( valores[ 2 ] );
            }
            catch( Exception e )
            {
                throw new Exception( "Error en la definición de rango" + i );
            }

            rango = new RangoImpuestos( inicio, fin, porcentaje );
            //Adiciona el rango
            RangoImpuestos.ensureCapacity( 1 );
            RangoImpuestos.add( i - 1, rango );
        }
    }

    /**
     * Busca, dado un valor, el rango de impuestos al que corresponde.
     * @param valor Valor a buscar.
     * @return rango de impuesto que contiene al valor o null si no lo encuentra.
     */
    private RangoImpuestos buscarRangoImpuesto( double valor )
    {
        RangoImpuestos rango = null;
        for( int i = 0; i < RangoImpuesto.size( ) && rango == null; i++ )
        {
            RangoImpuestos rangoAux = ( RangoImpuestos )RangoImpuestos.get( i );
            if( rangoAux.contieneA( valor ) )
                rango = rangoAux;
        }
        return rango;
    }

    /**
     * Retorna el valor de avalúo de un vehículo de la marca, línea y modelo dado. <br>
     * <b>pre: </b> La información de marcas, líneas y modelos de los vehículos ya fue inicializada correctamente.
     * @param unaMarca Marca del vehículo. unaMarca != null.
     * @param unaLinea Línea del vehículo. unaLinea != null.
     * @param unModelo Modelo del vehículo. unModelo != null.
     * @return precio de avalúo del vehículo.
     * @throws Exception si no encuentra la marca o la línea o el modelo registrados.
     */
    public double buscarAvaluoVehiculo( String unaMarca, String unaLinea, String unModelo ) throws Exception
    {
        Marca marca = buscarMarca( unaMarca );
        if( marca == null )
            throw new Exception( "La marca " + unaMarca + " no está registrada" );
        Linea linea = marca.buscarLinea( unaLinea );
        if( linea == null )
            throw new Exception( "La línea " + unaLinea + " no está registrada" );
        Modelo modelo = linea.buscarModelo( unModelo );
        if( modelo == null )
            throw new Exception( "El modelo " + unModelo + " no está registrado" );
        return modelo.darPrecio( );
    }

    /**
     * Calcular el pago de impuesto que debe hacer un vehículo de un modelo dado. Si no encuentra un rango para el modelo devuelve 0.<br>
     * <b>pre: </b> La información de marcas, líneas y modelos de los vehículos ya fue inicializada correctamente.
     * @param unaMarca Marca del vehículo. unaMarca != null.
     * @param unaLinea Línea del vehículo. unaLinea != null.
     * @param unModelo Modelo del vehículo. unModelo != null.
     * @param descProntoPago Indica si aplica el descuento por pronto pago.
     * @param descServicioPublico Indica si aplica el descuento por servicio público.
     * @return valor a pagar de acuerdo con las características del vehículo y los descuentos que se pueden aplicar.
     * @throws Exception si no encuentra el vehículo dado por la marca, la línea y el modelo.
     */
    public double calcularPago( String unaMarca, String unaLinea, String unModelo, boolean descProntoPago, boolean descServicioPublico, boolean descTrasladoCuenta ) throws Exception
    {
        double pago = 0.0;
        double precio = buscarAvaluoVehiculo( unaMarca, unaLinea, unModelo );
        //Calcula el impuesto según el precio del vehículo
        RangoImpuestos rango = buscarRangoImpuestos( precio );
        if( rango != null )
            pago = precio * ( rango.darPorcentaje( ) / 100.0 );
        // Aplica descuento por pronto pago
        if( descProntoPago )
            pago -= pago * ( PORC_DSC_PRONTO_PAGO / 100 );
        // Aplica descuento por ser un vehículo de servicio publico
        if( descServicioPublico )
            pago -= DESC_SERVICIO_PUBLICO;
      
        //si por descuentos se va a número negativo se deja en cero
        if( pago < 0 )
            pago = 0;
        return pago;
    }

    private static class Marca {

        public Marca() {
        }
    }
}